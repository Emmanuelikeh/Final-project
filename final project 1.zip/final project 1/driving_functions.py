import random
import time
from colorama import Fore, Style
from questions import QUESTION
import pygame


def tune(figure):
    """
        plays a particular sound depending on a pre-determined figure(integer)
    Args:
        figure: an integer that represents a particular sound
            return: None"""
    if figure == 1:
        applause = pygame.mixer.Sound('music/applause.wav')
        applause.play()
        time.sleep(6.2)
    elif figure == 2:
        incorrect = pygame.mixer.Sound('music/Buzzer.mp3')
        incorrect.play()
        time.sleep(2)
    elif figure == 3:
        intro = pygame.mixer.Sound('music/million dollar music.mp3')
        intro.play()
        time.sleep(20.5)
    elif figure == 4:
        outro = pygame.mixer.Sound('music/outro.mp3')
        outro.play()
        time.sleep(10)
    elif figure == 5:
        celebrate = pygame.mixer.Sound('music/chantvictory.wav')
        celebrate.play()


def asktheaudience():
    """ generates four random numbers that add up to 100,
        and each random number represents a percentage of the audience
        Args: None.
        return: None."""
    audience_percent = 100
    new_list = []
    for times in range(1, 5):
        letter_percent = random.uniform(0, audience_percent)
        audience_percent -= letter_percent
        new_list.append(round(letter_percent, 2))
    print('\n' + str(new_list[0]) + ' percent of the audience think the answer is A ')
    print(str(new_list[1]) + ' percent of the audience think the answer is B ')
    print(str(new_list[2]) + ' percent of the audience think the answer is C ')
    print(str(new_list[3]) + ' percent of the audience think the answer is D ')


def phoneafriend(name):
    """ simulates a phone conversation between the user and their friend, at the the end of
        the conversation the user's friend attempts to answer the question presented
        Args:
            name: a string that contains the users name
        return: None."""
    friend = random.choice(['Jessica', 'Dave'])
    options = random.choice(['A', 'B', 'C', 'D', 'E'])

    if friend == 'Jessica':
        print('Jessica is on the line')
        print('Hi ' + name, ' how are you doing')
        print(' i have been made aware that your are contesting in who wants to be a millionaire')
        if options in 'ABCD':
            print('I think the answer is ' + options)
        else:
            print(' I am sorry bro, I have no idea')
    if friend == 'Dave':
        print('Dave is on the line')
        print('Hi ' + name, ' how are you doing')
        print('i have been made aware that your are contesting in who wants to be a millionaire')
        if options in 'ABCD':
            print('I think the answer is ' + options)
        else:
            print(' I am sorry, I have no idea')


def usecount(hashmap, name):
    """  allows access to life lines and keeps track of the number of times available to use each life line
            Args:
                name: a string that contains the users name
                hashmap: a dictionary  that keeps track of the number times a life line has been used
            return: None."""
    while True:
        print('\nyou have one attempt per each life line')
        print(
            "Type 'A' if you would like to ask the audience or 'P' if you would like to phone a friend"
        )
        userinput = input().upper()
        if userinput not in ['A', 'P']:
            print('\nType in the correct represented letter')
        elif hashmap[userinput] > 0:
            print('you have already used this lifeline, pick another one')
        else:
            hashmap[userinput] += 1
            if userinput == 'A':
                asktheaudience()
            elif userinput == 'P':
                phoneafriend(name)
            break


def amountearned(num):
    """   determines the amount the user has earned as they progress through the game
         Args:
                num: an integer that represents each round of gameplay
          return- an integer that represents money earned after completing each round."""
    payout = [
        500, 1000, 2000, 3000, 5000, 7000, 10000, 15000, 20000, 30000, 50000,
        100000, 250000, 500000, 1000000
    ]
    money = payout[num - 1]
    return money


def checkpoint(num):
    """
          Args:
                num: an integer that represents each round of gameplay
         return: an integer that represents guaranteed money a user walks away with
         depending on the round they exit the game ."""
    if num <= 5:
        checkpointmoney = 0
    elif num > 5 and num <= 11:
        checkpointmoney = 5000
    elif num > 11 and num < 15:
        checkpointmoney = 50000
    return checkpointmoney


def finaldecision(response, rounds):
    """   At the end of the gameplay the function decides the amount the user walks away with and outcome of the game
    play based of the users response to a question
           Args:
                rounds: an integer that represents each round of gameplay
                response: a string that shows containing information on
                whether the users answer to a question  was wrong or not
            return- None """
    print('\n')
    if response == 'wrong!':
        print('i am sorry, this is were the game ends unfortunately')
        number = str(checkpoint(rounds))
        print('you still work away with ' + number + ' dollars')
    else:
        tune(5)
        time.sleep(2)
        print(
            "congratulations on winning the game you amongst the lucky few to join the millionaire club"
        )
        tune(4)
    print(
        "\nOn behalf our producers and creators of this show I would like to say Thank you to all our viewers at home, "
        " Have a Happy November, see you next time")


def introduction():
    """   a simple introduction before the game begins where the users name is obtained
       Args: None
            return: a string that represents the users name"""
    print(
        '------------------------------\n who wants to be a millionaire \n------------------------------\n'
    )
    print('\n please stand by')
    tune(3)
    print(
        '\n welcome to who wants to be a millionaire, a fun game show were our love for trivia is spread and we '
        'eagerly crown our next Millionaire \n ')
    name = input('please introduce your self: ' + '\n')
    print('Glad you could be here ' + name +
          ' the questions would begin shortly \n')
    return name


def roundspecifics(numbers):
    """   informs the user about special objectives of a particular round and also informs them when they move
          to a new round
         Args:
                   numbers: an integer that represents each round of gameplay
            return- None."""
    if numbers != 15:
        print('\n------ NEXT ROUND----- \n')
    if (numbers + 1) in [5, 11]:
        print('you have currently reached a check point round \n')


def examination():
    """
       selects a random question from a dictionary of questions
        in the constant variable (QUESTION) and displays to the user,
       Args: None
            return: a variable answer that contains the correct answer to a particular question presented."""
    query = QUESTION.pop(random.randint(0, len(QUESTION) - 1))
    quiz = query['question']
    print(Fore.YELLOW + quiz + Style.RESET_ALL + '\n')
    answer = query['answer']
    return answer


def lifelineuse(question_assistance, name):
    """
         keeps track of the number of times the option to choose a lifeline is available for the user to use.
         Args:
              name : an integer that represents each round of gameplay
            question_assistance: a dictionary that keeps track of the number of times a assistance for a question
             has been used
         return: None """
    while True:
        use = input('Do your want to use your life lines, y or n?').upper()
        if use not in ['Y', 'N']:
            print('Type in the correct letter')
            continue
        elif use == 'Y':
            usecount(question_assistance, name)
            question_assistance['usagecount'] += 1
            break
        else:
            print('no problem')
            break
