from driving_functions import amountearned, checkpoint
import unittest


class Testdrivingfunctions(unittest.TestCase):
    """
  Class for testing driving function.
  """

    def test_amount(self):
        self.assertEqual(amountearned(5), 5000)
        self.assertEqual(amountearned(8), 15000)
        self.assertEqual(amountearned(15), 1000000)
        self.assertEqual(amountearned(3), 2000)

    def test_checkpoint(self):
        self.assertEqual(checkpoint(4), 0)
        self.assertEqual(checkpoint(7), 5000)


if __name__ == '__main__':
    unittest.main()
