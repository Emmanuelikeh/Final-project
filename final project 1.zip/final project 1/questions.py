QUESTION = [{
    'question':
    "What sort of animal is Walt Disney's Dumbo? A.Deer B.Rabbit C.Elephant D.Donkey ",
    'answer': 'C'
}, {
    'question':
    "What was the name of the Spanish waiter in the TV sitcom 'Fawlty Towers'? A.Manuel B.Pedro C.Alfonso D.Javier",
    'answer': 'A'
}, {
    'question':
    "Which battles took place between the Royal Houses of York and Lancaster? A.Thirty Years War B.Hundred Years War C.War of the Roses D.English Civil War",
    'answer': 'C'
}, {
    'question':
    'Which former Beatle narrated the TV adventures of Thomas the Tank Engine? A.John Lennon B.Paul McCartney C.George Harrison D.Ringo Starr',
    'answer': 'D'
}, {
    'question':
    'Queen Anne was the daughter of which English Monarch? A.James II B.Henry VIII C.Victoria D.William I',
    'answer': 'A'
}, {
    'question':
    'Who composed "Rhapsody in Blue"? A.Irving Berlin B.George Gershwin C.Aaron Copland D.Cole Porter',
    'answer': 'B'
}, {
    'question':
    'Suffolk Punch and Hackney are types of what A.Carriage B.Wrestling style C.Cocktail D.Horse',
    'answer': 'D'
}, {
    'question':
    'What is the Celsius equivalent of 77 degrees Fahrenheit? A.15 B.20 C.25 D.30',
    'answer': 'C'
}, {
    'question':
    'Which Shakespeare play features the line "Neither a borrower nor a lender be"?A.Hamlet B.Macbeth C.Othello D.The Merchant of Venice',
    'answer': 'A'
}, {
    'question':
    "Which is the largest city in the USA's largest state?A.Dallas B.Los Angeles C.New York D.Yakutat",
    'answer': 'D'
}, {
    'question':
    'The word "aristocracy" literally means power in the hands of whom?A.The few B.The best C.The barons D.The rich',
    'answer': 'A'
}, {
    'question':
    'Where would a "peruke" be worn? A. Around the neck B.On the head C.Around the waist D.On the wrist',
    'answer': 'B'
}, {
    'question':
    'In which palace was Queen Elizabeth I born? A.Greenwich B.Richmond C. Hampton Court D.Kensington ',
    'answer': 'A'
}, {
    'question':
    "From which author's work did scientists take the word 'quark'? A.Lewis Carroll B.Edward Lear C.James Joyce D. Aldous Huxley",
    'answer': 'C'
}, {
    'question':
    'Which of these islands was ruled by Britain from 1815 until 1864? A.Crete B.Cyprus C.Corsica D.Corfu',
    'answer': 'D'
}]
