# Instructions for gameplay
## Who wants to be a millionaire
1. Introduction
    1. Who wants to be a millionaire is a popular american television program adapted from the same-titled British program created by David Briggs. The show features a quiz game with contestants attempting to win a top prize of one million dollars by answering a seres of multiple choice questions, usually of increasing difficulty.For more information visit (https://en.wikipedia.org/wiki/Who_Wants_to_Be_a_Millionaire_(American_game_show)) 


2. About the program
   1. The program is a simply a replica of who wants to be a millionaire television show made entirely in python program language

   2. Knowledge on Python Data structures was fundamental in the construction and organization of the program


3.  Creator Notes
    1. The creator envisions that through this program, knowledge acquisition on numerous areas ranging from History to Music to Current World Affairs would be  promoted.



4. Game  Play Rules
    1. For each game play, a user is allowed to attempt a maximum of fifteen(15) questions which make up fifteen(15) rounds

    2. Each question would be accompanied by a series of possible answers(options) with appropriate titles (A, B, C, D)

    3.  A feature, Lifelines (help option), which provides a form of assistance for a particular question is available for users to use

    4. There exist only two options in the lifelines feature, 'Asktheaudience' and 'Phoneafriend' 

    4. A user can attempt to use the "Lifelines feature" a maximum of two times throughout the entire game play and only use a Lifelines feature option once throughout the entire gameplay.

    5. After every question is displayed, space is provided for the user to input the option LETTER (A,B,C,D) that potentially corresponds to the correct answer

    6. If a player inputs the correct option letter, The amount earned for that particular round is displayed and the user progresses to the next round of questions up until the fifteenth round of questions

    7. Certain rounds exist in the gameplay and serve a Checkpoints. Checkpoints here means a rounds in the gameplay where a user is guaranteed to walk away with a specific amount of money when they successfully pass that round  

    8. If a player inputs a wrong option letter, a number or anything other than the correct option LETTER, the game would end for the user and the user walks away with money earned at the recently passed checkpoint
    
    9. If a player is able to successfully answer all the questions provided in each of the rounds, The player wins the game and is officially a millionaire



5. How to run the program
     1. After downloading the file, upload it to any suitable IDE apart from replit
     2. Go to the terminal (shell)
     3. Type in ```python main.py ``` to run the program successfully