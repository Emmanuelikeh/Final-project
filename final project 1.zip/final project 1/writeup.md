# Project writeup


## Motivation 

I enjoy learning. When I say this to my colleagues, they often give me strange glances, but in all seriousness, there is no finer feeling than realizing something you had no idea about the day before. From simple flyers to endless collections of academic journals, to articles on Buzzfeed explaining theories on the existence of alien life, learning about the simplest things from multiple perspectives was always enjoyable, and tuning in to Who Wants to Be a Millionaire on Sunday evenings was always a highlight of my week.With my love of studying and my recently acquired programming skills, I wanted to integrate both of these vital aspects of my life into something useful for this class and for myself, thus the birth of this project.

## Major Challenges in implementation 

To say this project was difficult would be an understatement; it required a lot more work than I anticipated, particularly when it came to structuring the question and answer procedure, using appropriate data structures, and working mainly with  things we had discussed in class. I also had a lot of trouble adding sound (extension) because I had to use a  new software (pycharm)  that I wasn't familiar with. Overall, the process of creating and building the program was very difficult, but I believe it pushed me to become a better programmer.

## Core functionality of the program

As per my vision, I created a command-line-based  interactive  quiz program that will ask the user a series of questions covering areas such as sports, politics and general knowledge, and would require the user's input to proceed. 

If a user fails to input the correct answer the user's journey in the game would end . Virtual monetary earnings would increase as the user proceeds in the game. I committed to  implementing ‘’who wants to be a millionaire ‘’ standard practices and added checkpoints that serve as guaranteed monetary earnings depending on how far the user reaches in the game. Lifeline options( ask the audience and phone a friend)  attributed to the game show were also implemented in the final product.
