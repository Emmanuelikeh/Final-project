from driving_functions import amountearned, finaldecision, introduction, roundspecifics, examination, lifelineuse, tune
from pygame import mixer
from colorama import Fore, Style


def main():
    # main driving force of the game
    mixer.init()
    name = introduction()
    question_assistance = {'A': 0, 'P': 0, 'usagecount': 0}
    for rounds in range(1, 16):
        answer = examination()
        if question_assistance['usagecount'] < 2:
            lifelineuse(question_assistance, name)
        attempt = input("\nType in your option letter\n").upper()
        if attempt == answer:
            response = 'That is right!'
            earnings = str(amountearned(rounds))
            print(Fore.GREEN + response + Style.RESET_ALL)
            print('You have currently made ' + earnings + ' dollars so far ')
            tune(1)
            roundspecifics(rounds)
        else:
            response = 'wrong!'
            print(Fore.RED + response + Style.RESET_ALL)
            tune(2)
            break
    finaldecision(response, rounds)


if __name__ == '__main__':
    main()
